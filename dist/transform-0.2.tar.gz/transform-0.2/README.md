# transformations
A library for transformations

Developed by -
    Satyam Bhardwaj
    Anish Bhanu

Start:

import transform as tf
tf.circle( (center), radius ) -> draws a circle
tf.rotate(Xpoints, Ypoints, radians, "c(forClockwise, else "a")", origin) -> does the job of rotating
and much more.. 
